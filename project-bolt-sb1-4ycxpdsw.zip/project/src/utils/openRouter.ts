interface OpenRouterMessage {
  role: 'user' | 'assistant';
  content: string | {
    type: string;
    text?: string;
    image_url?: {
      url: string;
    };
  }[];
}

interface OpenRouterResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}

export async function callOpenRouter(messages: OpenRouterMessage[]): Promise<string> {
  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${import.meta.env.VITE_OPENROUTER_API_KEY}`,
        "HTTP-Referer": window.location.origin,
        "X-Title": "AI Lecture Planner",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        "model": "google/gemini-2.0-pro-exp-02-05:free",
        "messages": messages
      })
    });

    if (!response.ok) {
      throw new Error(`OpenRouter API error: ${response.statusText}`);
    }

    const data: OpenRouterResponse = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error calling OpenRouter:', error);
    throw error;
  }
}

export async function processSyllabus(content: string) {
  const prompt = `
    Analyze this course syllabus and extract the following information in JSON format:
    - Course title
    - Course description
    - Target level
    - List of topics, where each topic includes:
      - Title
      - Description
      - Estimated difficulty (1-5)
      - Estimated duration (in minutes)
      - Prerequisites
      - Learning objectives
      - Suggested resources
    
    Syllabus content:
    ${content}
  `;

  const response = await callOpenRouter([
    {
      role: 'user',
      content: prompt
    }
  ]);

  return JSON.parse(response);
}