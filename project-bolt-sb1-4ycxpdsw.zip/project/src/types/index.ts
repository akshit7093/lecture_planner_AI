export interface Topic {
  id: string;
  title: string;
  description: string;
  difficulty: number;
  duration: number;
  prerequisites: string[];
  learningObjectives: string[];
  resources: string[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  targetLevel: string;
  topics: Topic[];
}

export interface FlowNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: Topic;
}

export interface FlowEdge {
  id: string;
  source: string;
  target: string;
}