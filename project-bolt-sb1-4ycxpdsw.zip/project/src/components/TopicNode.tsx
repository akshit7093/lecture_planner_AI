import React from 'react';
import { Handle, Position } from 'reactflow';
import { Edit2, Trash2, Clock, Book } from 'lucide-react';
import { Topic } from '../types';

interface TopicNodeProps {
  data: Topic;
  onEdit: (topic: Topic) => void;
  onDelete: (id: string) => void;
}

const difficultyColors = {
  1: 'bg-green-100',
  2: 'bg-green-200',
  3: 'bg-yellow-200',
  4: 'bg-orange-200',
  5: 'bg-red-200',
};

export const TopicNode: React.FC<TopicNodeProps> = ({ data, onEdit, onDelete }) => {
  return (
    <div className={`p-4 rounded-lg shadow-md ${difficultyColors[data.difficulty]} w-64`}>
      <Handle type="target" position={Position.Top} />
      
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-lg">{data.title}</h3>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit(data)}
            className="p-1 hover:bg-black/10 rounded"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(data.id)}
            className="p-1 hover:bg-black/10 rounded text-red-600"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="text-sm text-gray-600 mb-2">{data.description}</div>

      <div className="flex items-center gap-2 text-sm text-gray-600">
        <Clock size={14} />
        <span>{data.duration} mins</span>
        <Book size={14} className="ml-2" />
        <span>Difficulty: {data.difficulty}/5</span>
      </div>

      <Handle type="source" position={Position.Bottom} />
    </div>
  );
};